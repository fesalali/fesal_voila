# DateTime Form Type
Showing datepicker and time in the input type

### Code Sample
```php
$this->form[] = ['label'=>'DateTime Event','name'=>'datetime','type'=>'datetime'];
```
## What's Next
- [Form Input Type: email](./form-email.md)

## Table Of Contents
- [Back To Index](./index.md)