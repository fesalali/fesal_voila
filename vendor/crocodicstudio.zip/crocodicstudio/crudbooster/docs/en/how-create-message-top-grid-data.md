# How To Create A Message Info At Top Of Grid Data (Bootstrap Alert)

```php
$this->alert[] = ['message'=>'Your message goes here...','type'=>'info'];
```
In the `type` attribute you can fill info,success,warning,danger

## What's Next
- [How To Change Color Of Row With Specific Condition](./how-custom-color-row.md)

## Table Of Contents
- [Back To Index](./index.md)