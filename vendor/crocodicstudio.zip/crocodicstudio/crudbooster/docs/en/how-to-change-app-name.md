## How To Change The Application Name

1. Go to Settings -> Application Setting
2. Change the value of **Application Name** input.
3. Save.

## What's Next
- [How To Make A Custom View Of Index Method](./how-to-custom-index.md)

## Table Of Contents
- [Back To Index](./index.md)